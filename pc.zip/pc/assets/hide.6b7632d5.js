var a="/img/welcomebg.png",g="/img/show.png",i="/img/hide.png";export{g as _,i as a,a as b};
