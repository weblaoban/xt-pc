import{a as t,b as r}from"./index.7cc1cd3e.js";const e=o=>t({url:r+"/prodComm",method:"post",data:{...o}}),m=o=>t({url:r+"/shop/notice/info",method:"get"});export{e as addComment,m as getAmount};
