var p="/img/play.png";export{p as _};
