var p="/img/kefu.png";export{p as _};
